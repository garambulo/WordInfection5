<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AccountController extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('UserAccount_m');
	}

	public function View($Page){
		session_unset('Information');
		if($Page == "Login"){
			Template::render('Authentication/Login');
		}
		elseif ($Page == "Registration") {
			Template::render('Authentication/Registration');
		}
		elseif ($Page == "Demographic_Profile") {
			Template::render('Demographic_Profile/index');
		}
		elseif ($Page == "Computer_Skills") {
			Template::render('Computer_Skills/index');		}
		$_Session['Page'] = $Page;
		
	}

	//for login
	public function ValidateAccount(){
		$query = array(
			'username' => $this->input->post('txt_Username'),
			'password' => $this->input->post('txt_Password')
		);
		if($this->UserAccount_m->Check_Account($query)){
			echo "<script type='text/javascript'>alert('May Account!');</script>";
			redirect("GameController/Game_Menu");
			//ilagay sa session si user
			//check kung anong difficulty na si user
			//redirect sa game difficulty or kung saang page na siya dapat
			//iredirect sa game page

		}
		else{
			echo "<script type='text/javascript'>alert('Walang Account!');</script>";
			
		}

	}
	//for register
	public function ValidateAccount_Info(){
		//check kung na fill na lahat ng info
		//check kung may same username na
		//if walang kaparehas, redirect sa demog profile na view
		redirect("AccountController/View/Demographic_Profile");
		
		//if meron, show a message na user exists
		//maghanap ng pang validate na hindi maaalis si info pag nirefresh

	}
	//for demographic
	public function ValidateProfile_Info(){
		//check kung na fill na lahat ng info
		//if yes, show computer skills
		redirect("AccountController/View/Computer_Skills");
		//if no show uli yung

	}

	//for computer Skills
	public function ValidateSkills(){
		redirect("GameController/LoadQuestion/Test_Easy");
	}

	
}
