<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GameController extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Quiz_m');
		$this->load->library('session');
	}

	public function LoadQuestion($QuestionType)// Question Type either Pre-test/Post-Test, Game (One choice)
	{

		// session_unset();
		$data['RandomizedQuestions'] = array();
		if(isset($_SESSION['Information'])){
			foreach ($_SESSION['Information']['RandomizedQuestions']  as $RandomizedQuestions) {
				$data['RandomizedQuestions'][] = $RandomizedQuestions;
			}
			$data['Number'][] = $_SESSION['Information']['Number'][0];
			$data['Score'][] = $_SESSION['Information']['Score'][0];
			$data['Page'][] = $_SESSION['Information']['Page'][0];
		}
		else{
			$questions = $this->Quiz_m->get_all_questions($QuestionType);
			$arrNum_List = GameUtil::randomizeNumber(sizeof($questions));
			foreach ($arrNum_List as $RandomNumber) {
				$data['RandomizedQuestions'][] = $questions[$RandomNumber];
			}
			$data['Page'][] = $QuestionType;
			// $data['Page'][] = $this->encryption->encrypt($QuestionType);
			$data['Number'][] = 0;
			$data['Score'][] = 0;
			$_SESSION['Information'] = $data;
		}
		
		// echo "<pre>";
		// print_r($_SESSION['Information']);
		// echo "</pre>";

		
		Template::render($QuestionType.'/index', $data);

	}
	// for the quiz
	public function validateAnswer(){
		if(!empty($_SESSION['Information']))
		{
			$Number = $_SESSION['Information']['Number'][0];
			$Score = $_SESSION['Information']['Score'][0];
			$Page = $_SESSION['Information']['Page'][0];
			// validation for score
			if((($Number+1)-$Score) >= 3){
				// remove session
				session_unset();
				//show game over then redirect sa menu na yes/no
				//if yes but  
					//redirect sa same page
				//if no
				//redirect sa choose difficulty
				redirect("GameController/Game_Menu");
			}
			// validation for number
			if(($Number+1) >= 10){
				//remove session
				session_unset();
				//Show Congratulations
				//insert info sa database
				//Show Congratulations then redirect sa page na pipili ng difficulty
				redirect("GameController/Game_Menu");
				
			}
			
			
			$Answer = trim(strtolower($this->input->post('Answer')));
			$CorrectAnswer = trim(strtolower($_SESSION['Information']['RandomizedQuestions'][$Number]->Answer));
			if($Answer === $CorrectAnswer){
				$_SESSION['Information']['Score'][0] = $Score +1;
			}
			$_SESSION['Information']['Number'][0] = $Number +1;
			redirect("GameController/LoadQuestion/".$Page);
		}
		else{
			//redirect sa error page
			print_r("Walang Session!");
		}
		
	}

	//For the pre test and post test 
	public function validateAnswers($TestType){
		$Answers = $this->input->post('Answers');
		$count = 0;
		foreach ($Answers as $key => $Answer) {
			$CorrectAnswer = trim(strtolower($_SESSION['Information']['RandomizedQuestions'][$key]->Answer));
			if($CorrectAnswer == trim(strtolower($Answers[$key]))){
				$count = $count + 1;
			}
			print_r("Correct Answer: " . $CorrectAnswer) . "<br>";
			print_r("Answer: " . $Answer . "<br>");
		}
		echo "<pre>";
		print_r($count);
		echo "</pre>";
		// if($TestType == "Test_Easy"){
		// 	session_unset('Information');
		// 	//store sa database
		// 	redirect("GameController/LoadQuestion/Test_Average");

		// } elseif ($TestType == "Test_Average") {
		// 	session_unset('Information');
		// 	//store sa database
		// 	redirect("GameController/LoadQuestion/Test_Difficult");
		// } elseif ($TestType == "Test_Difficult") {
		// 	session_unset('Information');
		// 	//store sa database
		// 	//lagay ng session para makita na tapos na si difficult at maging visible si game menu
		// 	redirect("GameController/Game_Menu");
		// }

	}

	//load the game menu
	public function Game_Menu(){
		session_unset('Information');
		Template::render('DifficultyLevels/index');
	}
	//selecting different difficulty in game menu
	public function SelectDifficultyLevel(){
		$DifficultyLevel = $this->input->post('Answer');
		if($DifficultyLevel == "Easy"){
			redirect("GameController/LoadQuestion/Quiz_Easy");
		} elseif ($DifficultyLevel == "Average") {
			redirect("GameController/LoadQuestion/Quiz_Average");
		} elseif ($DifficultyLevel == "Difficult") {
			redirect("GameController/LoadQuestion/Quiz_Difficult");
		} else{
			// load error page
		}
	}
}
