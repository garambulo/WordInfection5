<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class GameUtil{
	public static function randomizeNumber($count){
		$RandomNum_List = array();
		for ($i=1; $i <= 10; $i++) {
			$isGenerated = false;
			do {
				//generate random number
				$Randomed_Number = (mt_rand(1, $count-1));
				//check if nasa array yung randomized number
				if(in_array($Randomed_Number, $RandomNum_List)){
					$isGenerated = true;
				}else{
					$RandomNum_List[] = $Randomed_Number;
					$isGenerated = false;
				}
			} while ($isGenerated === true);
			
		}
		return $RandomNum_List;
	}
}