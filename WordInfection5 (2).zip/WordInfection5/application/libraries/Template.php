<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Template{
	
	public static function render($body, $param = null)
	{
		$CI =& get_instance();
		$CI->load->view('Header');
		if ($param != null)
			$CI->load->view($body, $param);
		else
			$CI->load->view($body);
		$CI->load->view('Footer');
	}
}