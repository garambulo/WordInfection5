<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Validations{
	public static function AlreadySet($data){
		if(isset($data))
			return true;
		else
			return false;
	}
}