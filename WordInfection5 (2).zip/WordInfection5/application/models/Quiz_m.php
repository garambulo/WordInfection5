<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quiz_m extends CI_Model {

  private $quiz_easy = 'tbl_quiz_easy';
  private $quiz_average = 'tbl_quiz_average';
  private $quiz_difficult = 'tbl_quiz_difficult';

  public function __construct()
  {
    parent::__construct();
  }

  public function get_all_questions($Quiz_Type,$query = null)
  {
    $result;
    // $result = $this->db->get($this->quiz_average);
    if($query != null){
      $this->db->where($query);
    }
    if($Quiz_Type == "Quiz_Easy" || $Quiz_Type == "Test_Easy"){
      $result = $this->db->get($this->quiz_easy);
    } elseif($Quiz_Type == "Quiz_Average" || $Quiz_Type == "Test_Average"){
      $result = $this->db->get($this->quiz_average);
    } elseif($Quiz_Type == "Quiz_Difficult" || $Quiz_Type == "Test_Difficult"){
      $result = $this->db->get($this->quiz_difficult);
    } else{
      return null;
    }
    

    // $this->db->select('*')->from($this->quiz_difficult);
    // $result = $this->db->get();  

    return $result->result();
  }

}//END OF CLASS