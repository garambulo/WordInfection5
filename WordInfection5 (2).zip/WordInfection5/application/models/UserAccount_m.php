<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserAccount_m extends CI_Model {

  private $UserAccount = 'tbl_UserAccount';

  public function __construct()
  {
    parent::__construct();
  }

  public function Check_Account($query = null)
  {
    if($query != null)
      $this->db->where($query);

    $this->db->select('*')->from($this->UserAccount);
    $result = $this->db->get()->result();
    if(sizeof($result)>0)
      return true;
    else
      return false;
  }

}//END OF CLASS