

<!-- Contact Section -->
<br/><br/>
<form action="<?php echo base_url(); ?>AccountController/ValidateAccount" method="post">
<section id="contact">
  <div class="container">
    <h2 class="text-center">Login to Word Infection 5</h2>
    <hr class="star-primary">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
        <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
        <form name="sentMessage" id="contactForm" novalidate>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Username</label>
              <input class="form-control" id="username" type="text" placeholder="Username" required data-validation-required-message="Username">
              <p class="help-block text-danger"></p>
          </div>
      </div>
      <div class="control-group">
        <div class="form-group floating-label-form-group controls">
          <label>Password</label>
          <input class="form-control" id="password" type="password" placeholder="Password" required data-validation-required-message="Password">
          <p class="help-block text-danger"></p>
      </div>
  </div>
  <br>
  <div id="success"></div>
  <div class="form-group">
    <span class="newline" style="display:flex;justify-content:center;align-items:center;">
      <input type="submit" class="enjoy-css" value="Login" style="padding: 10px 10px;"/>
  </span>
</div>
</form>
</div>
</div>
</div>
</section>

</form>