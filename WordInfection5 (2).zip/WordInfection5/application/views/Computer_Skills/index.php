<form action="<?php echo base_url(); ?>AccountController/ValidateSkills" method="post">
<!-- Contact Section -->
<section id="contact">
  <div class="container">
    <span class="newline"> <br/> <br/>
      <h2 class="text-center">Computer Skills</h2>
      <hr class="star-primary">
      <div class="row">
        <div class="col-lg-8 mx-auto" style="margin: 0 auto;">
          <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
          <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
          
          <p>1. Are you computer literate?</p>
          <form action="" id="q1">
            <input type="radio" name="x" value="1"> Yes<br>
            <input type="radio" name="x" value="2"> No<br>
          </form> <br/> <br/>

          <p>2. Do you own a laptop/desktop?</p>
          <form action="" id="q2">
            <input type="radio" name="x" value="1"> Yes<br>
            <input type="radio" name="x" value="2"> No<br>
          </form> <br/> <br/>

          <p>3.	How long do you use your laptop/desktop daily? </p>
          <form action="" id="q3">
            <input type="radio" name="x" value="1"> 1 - 2 hours<br>
            <input type="radio" name="x" value="2"> 3 - 6 hours<br>
            <input type="radio" name="x" value="3"> 7 - 10 hours<br>
          </form> <br/> <br/>

          <p>4.	Do you have installed internet browsers on your devices (Laptop/Desktop/Mobile Phone/Tablet)?</p>
          <form action="" id="q4">
            <input type="radio" name="x" value="1"> Yes<br>
            <input type="radio" name="x" value="2"> No<br>
          </form> <br/> <br/>

          <p>5.	What internet browser do you frequently use? </p>
          <form action="" id="q5">
            <input type="checkbox" name="x" value="1"> Google Chrome<br>
            <input type="checkbox" name="x" value="2"> Mozilla Firefox<br>
            <input type="checkbox" name="x" value="3"> Internet Explorer<br>
            <input type="checkbox" name="x" value="4"> Safari<br>
          </form> <br/> <br/>

          <p>6.	Do you know how to properly use internet browser settings?</p>
          <form action="" id="q6">
            <input type="radio" name="x" value="1"> Yes<br>
            <input type="radio" name="x" value="2"> No<br>
          </form> <br/> <br/>

          <p>7.	Do you play games?</p>
          <form action="" id="q7">
            <input type="radio" name="x" value="1"> Yes<br>
            <input type="radio" name="x" value="2"> No<br>
          </form> <br/> <br/>

          <p>8.	What device do you usually use in playing games?</p>
          <form action="" id="q8">
            <input type="checkbox" name="x" value="1"> Laptop/Desktop<br>
            <input type="checkbox" name="x" value="2"> Tablet<br>
            <input type="checkbox" name="x" value="3"> Mobile Phone<br>
            <input type="checkbox" name="x" value="4"> Console<br>
          </form> <br/> <br/>
          
          <p>9.	What type of gamer are you? (You can check as many as possible) </p>
          <form action="" id="q9">
            <input type="checkbox" name="x" value="1"> PC Gamer<br>
            <input type="checkbox" name="x" value="2"> Mobile Gamer<br>
            <input type="checkbox" name="x" value="3"> Console Gamer<br>
          </form> <br/> <br/>

          <p>10.	Why do you play games?</p>
          <form action="" id="q10">
            <input type="checkbox" name="x" value="1"> For fun/leisure<br>
            <input type="checkbox" name="x" value="2"> Hobby<br>
          </form> <br/> <br/>

          <p>11.	What type of games do you play? (You can check as many as possible) </p>
          <form action="" id="q11">
            <input type="checkbox" name="x" value="1"> Puzzles<br>
            <input type="checkbox" name="x" value="2"> Adventure Games<br>
            <input type="checkbox" name="x" value="3"> Racing Games<br>
            <input type="checkbox" name="x" value="4"> Strategy Games<br>
            <input type="checkbox" name="x" value="5"> Vocabulary Games<br>
            <input type="checkbox" name="x" value="6"> Simulation Games<br>
            <input type="checkbox" name="x" value="7"> Multiplayer Games<br>
          </form> <br/> <br/>

          <span class="newline" style="display:flex;justify-content:center;align-items:center;">
            <input type="Submit" class="enjoy-css" value="Submit" style="padding: 10px 10px;"/>
          </span>
        </div>
      </div>
      </span>
      </div>
</section>
</form>
