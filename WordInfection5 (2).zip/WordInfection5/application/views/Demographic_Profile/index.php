<form action="<?php echo base_url(); ?>AccountController/ValidateProfile_Info" method="post">
<!-- Contact Section -->
<section id="contact">
  <div class="container">
    <span class="newline"> <br/> <br/>
      <h2 class="text-center">Demographic Profile</h2>
      <hr class="star-primary">
      <div class="row">
        <div class="col-lg-8 mx-auto" style="margin: 0 auto;">
          <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
          <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
          <form name="sentMessage" id="contactForm" novalidate>
            <div class="setwidth">
              <p style="word-spacing: 33px;"> 
                Name:  
                <input class="demog-tb" placeholder="Full Name" style="width: 100%;"/>
                
              </p>

              <p style="word-spacing: 5px; "> 
                Gender: 
                <select class="selectpicker" id="gender" name="Gender" placeholder="Gender" required data-validation-required-message="Gender" style="width: 100%; ">
                  <option>Male</option>
                  <option>Female</option>
                </select>
              </p>

              
                  <!--
                  <p style="float: left; word-spacing: 5px; "> 
                  Gender: 
                  <select class="selectpicker" id="gender" name="Gender" placeholder="Gender" required data-validation-required-message="Gender" style="width: 110px; ">
                              <option>Male</option>
                              <option>Female</option>
                  </select>
                  </p>
                -->
                

                <p style="word-spacing: 10px;">
                  Program: 
                  <select class="selectpicker" id="program" name="Program" placeholder="Program" required data-validation-required-message="Program" style="width: 100%;">
                    <optgroup label="Mapua-PTC College of Maritime Education and Training">
                      <option>Marine Engineering</option>
                      <option>Marine Transportation</option>
                    </optgroup>
                    <optgroup label="College of Arts and Science">
                      <option>Multimedia Arts</option>
                      <option>Communication</option>
                      <option>Environmental Science</option>
                    </optgroup>
                    <optgroup label="Mapua Institute of Technology at Laguna">
                      <option>Architecture</option>
                      <option>Chemical Engineering</option>
                      <option>Civil Engineering</option>
                      <option>Computer Engineering</option>
                      <option>Electrical Engineering</option>
                      <option>Electronics Engineering</option>
                      <option>Industrial Engineering</option>
                      <option>Mechanical Engineering</option>
                    </optgroup>
                    <optgroup label="E.T. Yuchengco College of Business">
                      <option>Accountancy</option>
                      <option>Hotel and Restaurant Management</option>
                      <option>Entrepreneurship</option>
                      <option>Tourism Management</option>
                      <option>Accounting Information Systems</option>
                    </optgroup>
                    <optgroup label="College of Computer and Information Science">
                      <option>Information Technology</option>
                      <option>Computer Science</option>
                      <option>Information Systems</option>
                    </optgroup>
                  </select>
                </p>
              <p style="word-spacing: 5px; "> 
                Year Level: 
                <select class="selectpicker" id="gender" name="Gender" placeholder="Gender" required data-validation-required-message="Gender" style="width: 100%; ">
                      <!--<option>1</option>
                      <option>2</option>
                      <option>3</option>-->
                      <option>4</option>
                      <option>5</option>
                    </select>
                  </p>
                  <span class="newline" style="display:flex;justify-content:center;align-items:center;">
                    <input type="Submit" class="enjoy-css" value="Submit" style="padding: 10px 10px;"/>
                  </span>
                  </div>
                </form>
              
            </div>
            </div>
          </span>
        </div>
      </section>
      </form>