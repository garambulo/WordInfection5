<form action="<?php echo site_url("GameController/SelectDifficultyLevel");?>" method="post">
  <br><br>
<section id="contact">
      <div class="container">
        <h2 class="text-center">Level Select</h2>
        <hr class="star-primary">
        <div class="row">
          <div class="col-lg-8 mx-auto">
            <form name="sentMessage" id="contactForm" novalidate>
              <div class="form-group">
                            <span class="newline" style="display:flex;justify-content:center;align-items:center;">
                              <input type="submit" name="Answer" class="enjoy-css" value="Easy" style="padding: 10px 10px;"/>
                            </span>
                            <span class="newline" style="display:flex;justify-content:center;align-items:center;">
                              <input type="submit" name="Answer" class="enjoy-css" value="Average" style="padding: 10px 10px;"/>
                            </span>
                            <span class="newline" style="display:flex;justify-content:center;align-items:center;">
                              <input type="submit" name="Answer" class="enjoy-css" value="Difficult" style="padding: 10px 10px;"/>
                            </span>
                        </div>
              </div>
              <div class="form-group">
                
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
</form>