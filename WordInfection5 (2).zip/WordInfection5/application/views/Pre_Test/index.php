	
	<form action="<?php echo base_url(); ?>GameController/validateAnswers" method="post">
		<?php foreach ($RandomizedQuestions as $key => $QandA): ?>
		<label>Question <?= $key+1  ?>: <?= $QandA->Question  ?></label><br>
		<input type="text" name="Answers[]"><br>
	<input type="hidden" name="CorrectAnswers[]" value="<?php echo $QandA->Answer ?>">
	<?php endforeach ?>
	<input type="submit" value="Submit">

	</form>