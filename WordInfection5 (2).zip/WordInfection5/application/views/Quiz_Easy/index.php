<form action="<?php echo site_url("GameController/validateAnswer");?>" method="post">
  <header class="masthead">
    <div class="container">
      <img class="img-fluid" src="img/profile.png" alt="">
      <div class="intro-text">
        <span class="name">Question <?php print_r($Number[0] + 1); ?></span>
        <hr class="star-light">
        <span class="skills"><?php print_r($RandomizedQuestions[$Number[0]]->Question);?></span>
        <br/><br/>
        <div class="setwidth">
          <span class="newline">
            <input type="Submit" name="Answer" class="enjoy-css" value="True"/>
          </span>

          <span class="newline">
            <input type="Submit" name="Answer" class="enjoy-css" value="False"/>
          </span>
        </div>
      </div>
    </div>
  </header>
</form>
