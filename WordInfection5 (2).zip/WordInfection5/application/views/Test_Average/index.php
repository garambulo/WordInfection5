
<form action="<?php echo site_url("GameController/validateAnswers/Test_Average");?>" method="post">
<!-- Contact Section -->
    <section id="contact">
      <div class="container">
        <span class="newline"> <br/> <br/>
        <h2 class="text-center">Pre-Test Average</h2>
        <hr class="star-primary">
        <div class="row">
          <div class="col-lg-8 mx-auto" style="margin: 0 auto;">
            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
            <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
            <form name="sentMessage" id="contactForm" novalidate>
                <div class="setwidth">
                  <form action="" id="">
                  <?php foreach ($RandomizedQuestions as $key => $QandA): ?>
              <p><?= ($key+1). ". ". $QandA->Question?></p>
              
                  <input type="radio" name="Answers[<?=  $key;?>]" value="<?php echo $QandA->Trick1; ?>"> <?php echo $QandA->Trick1; ?><br>
                  <input type="radio" name="Answers[<?=  $key;?>]" value="<?php echo $QandA->Trick2; ?>"> <?php echo $QandA->Trick2; ?><br>
                  <input type="radio" name="Answers[<?=  $key;?>]" value="<?php echo $QandA->Trick3; ?>"> <?php echo $QandA->Trick3; ?><br>
                  <input type="radio" name="Answers[<?=  $key;?>]" value="<?php echo $QandA->Answer; ?>"> <?php echo $QandA->Answer; ?><br>
                  <br/> <br/>
                  <?php endforeach ?>
              </form>

              <input type="Submit" class="enjoy-css" value="Submit"/>

                </div>
                </form>
          </div>
          
        </div>
        </span>
      </div>
    </section>
    </form>

