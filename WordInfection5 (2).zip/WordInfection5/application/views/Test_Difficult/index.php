
<form action="<?php echo site_url("GameController/validateAnswers/Test_Difficult");?>" method="post">
  <!-- Contact Section -->
  <section id="contact">
    <div class="container">
      <span class="newline"> <br/> <br/>
        <h2 class="text-center">Pretest</h2>
        <hr class="star-primary">
        <div class="row">
          <div class="col-lg-8 mx-auto" style="margin: 0 auto;">
            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
            <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
            <form name="sentMessage" id="contactForm" novalidate>
              <div class="setwidth">

                <br/> <br/> <br/>
                <form action="" id="q1">
                  <?php foreach ($RandomizedQuestions as $key => $QandA): ?>
                    <p><?= $key+1?>. <?= $QandA->Question  ?></p>

                    <input class="demog-tb" name="Answers[]"/>
                    <br/> <br/>
                  <?php endforeach ?>
                </form>
                <input type="Submit" class="enjoy-css" value="Submit"/>

              </div>
            </form>
          </div>
        </div>
      </span>
    </div>
  </section>
</form>
