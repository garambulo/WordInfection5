
<form action="<?php echo base_url(); ?>GameController/validateAnswers/Test_Easy" method="post">
  <!-- Contact Section -->
  <section id="contact">
    <div class="container">
      <span class="newline"> <br/> <br/>
        <h2 class="text-center">Pre-Test Easy</h2>
        <hr class="star-primary">
        <div class="row">
          <div class="col-lg-8 mx-auto" style="margin: 0 auto;">
            <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
            <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
            <form name="sentMessage" id="contactForm" novalidate>
              <div class="setwidth">

                <br/> <br/> <br/> 
                <form action="" id="">
                  <?php foreach ($RandomizedQuestions as $key => $QandA): ?>
                    <p><?= ($key+1). ". ". $QandA->Question?></p>

                    <input type="radio" name="Answers[<?=  $key;?>]" value="True"> True<br>
                    <input type="radio" name="Answers[<?=  $key;?>]" value="False"> False<br>
                    <br/> <br/>
                  <?php endforeach ?>
                </form>
                <input type="Submit" class="enjoy-css" value="Submit"/>

              </div>

              <!-- -->

              <!-- -->
            </form>
          </div>
        </div>
      </span>
    </div>
  </section>
</form>